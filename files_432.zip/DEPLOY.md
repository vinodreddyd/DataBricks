# DEPLOY.md — Final consolidated deployment guide

Everything you need to take this from a downloaded zip to a working Databricks App. This supersedes the older deployment docs in `docs/` — read this one.

> **What's in this package**: the FastAPI backend with a pre-built UI (`backend/static/index.html` is included — no `npm` needed), the parameterized notebook to drop into your existing pipeline folder, and supporting docs. Latest fixes for the issues we worked through:
> - Run no longer requires the `generated/` folder to exist
> - Frontend reads the actual API field names (no more PENDING-forever bug)
> - Modern Databricks URL pattern for the "Open in Databricks" link
> - Surfaces `state_message` so you can see why a run failed
> - Bulk-add tables with naming-convention detection (📋 Bulk add button)

---

## Table of contents

1. Prerequisites
2. Step 1 — Find your IDs and paths
3. Step 2 — Upload the App code
4. Step 3 — Upload `NoteBook_Main_Param` to your pipeline folder
5. Step 4 — Edit `app.yaml` to match YOUR paths
6. Step 5 — Edit the notebook's `sys.path` line
7. Step 6 — Create the App and bind the cluster
8. Step 7 — Smoke test
9. If something breaks
10. Updating later

---

## 1. Prerequisites

You need:

| Resource | Why |
|---|---|
| A Databricks workspace with **Apps enabled** | The whole feature you're deploying |
| An all-purpose cluster (RUNNING when you Run) | Where the ingestion pipeline executes |
| Your existing pipeline code already in the workspace | The App calls into it; not optional |
| Permission to create Apps + edit workspace files | If your account lacks this, ask your admin |
| The Databricks CLI installed locally | For uploading the `backend/` folder in one command (the only piece of laptop tooling needed) |

Install the CLI on your laptop if you don't have it (one-time):

```bash
# macOS / Linux
curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh

# Windows (PowerShell)
winget install Databricks.DatabricksCLI

# Authenticate (browser opens)
databricks auth login --host https://YOUR-WORKSPACE.cloud.databricks.com
```

> **Why the CLI?** The Databricks web UI doesn't support recursive folder upload. You'd be clicking through 30 files one at a time. The CLI does it in one command. There's a notebook-based fallback at the end of this doc if you absolutely cannot install the CLI.

---

## 2. Step 1 — Find your IDs and paths

Open your Databricks workspace in a browser. Collect these five values into a notes file. You'll need them all:

### A. Your user folder name

Look at the URL when you're in the Databricks workspace. Your user folder is the bit after `/Workspace/Users/`. Examples:

- `ashoka.pallapu@amtrak.com`
- `john.doe@company.com`

### B. Your existing pipeline folder path

Find the folder containing your existing `NoteBook_Main` (the one you currently use to run the pipeline). Click on the file, look at the breadcrumb at the top of the page. The **parent folder** path is what you need.

Example:
```
/Workspace/Users/ashoka.pallapu@amtrak.com/ashoka/dbx_ingestion/Data-Platform
```

### C. Your `platform-core` folder path

Inside the Data-Platform folder, there's a `platform-core/` subfolder containing `run_pipeline.py`. The path to the **`platform-core` folder itself** is what you need.

Example:
```
/Workspace/Users/ashoka.pallapu@amtrak.com/ashoka/dbx_ingestion/Data-Platform/platform-core
```

### D. Your cluster ID

Compute → click your all-purpose cluster → look at the URL. It contains an ID like `0501-123456-abc456` between `/clusters/` and the next `/`. Copy it exactly.

### E. Your SQL Warehouse ID *(only needed for History tab + future schema browser)*

SQL Warehouses → click your warehouse → URL contains an ID like `1a2b3c4d5e6f7g8h`. Copy it exactly.

If you don't have a SQL warehouse yet, leave this for later — the Build/Preview/Run tabs work without it.

---

## 3. Step 2 — Upload the App code

Download the zip and unpack it on your laptop.

```bash
unzip dbx_ingestion_app.zip
cd dbx_ingestion_app
```

Upload only the `backend/` folder to your workspace:

```bash
databricks workspace import-dir backend \
  /Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend
```

Replace `YOUR.EMAIL` with your actual user folder from Step 1A. Don't include the trailing slash.

Verify it landed:

```bash
databricks workspace list /Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend
```

You should see `app.py`, `app.yaml`, `static/`, etc. listed.

> **What about `frontend/` and `docs/`?** They're not needed at runtime. The frontend is already pre-built into `backend/static/index.html`. Docs are reference material only.

---

## 4. Step 3 — Upload `NoteBook_Main_Param` to your pipeline folder

This file goes **next to your existing `NoteBook_Main`**, not inside the App folder. The notebook has to live there so it can `import` your platform code.

In Databricks workspace browser:

1. Navigate to your existing `Data-Platform/` folder (the path from Step 1B)
2. Click **Create** → **Notebook** *(NOT File — this matters)*
3. Name: `NoteBook_Main_Param` *(no `.py` extension — Databricks adds it automatically for notebooks)*
4. Default language: Python
5. Click **Create**
6. The new empty notebook opens
7. On your laptop, open `databricks/NoteBook_Main_Param.py` from the unzipped project in any text editor
8. Copy the entire contents
9. Paste into the Databricks notebook editor
10. **Don't save yet** — proceed to Step 5 first to fix the `sys.path` line

> **Why "Notebook" and not "File"?** The Databricks Jobs API can only execute Notebooks, not regular Files. They look almost identical in the Create menu but Databricks treats them very differently.

---

## 5. Step 4 — Edit the notebook's `sys.path` line

Near the top of the notebook content you just pasted, find this line:

```python
sys.path.insert(
    0,
    "/Workspace/Users/your.email@company.com/dbx_ingestion/Data-Platform/platform-core",
)
```

Replace the path with **your actual `platform-core` path from Step 1C**. For example:

```python
sys.path.insert(
    0,
    "/Workspace/Users/ashoka.pallapu@amtrak.com/ashoka/dbx_ingestion/Data-Platform/platform-core",
)
```

Save the notebook (Cmd-S / Ctrl-S).

> **Verify it's right**: in your workspace, navigate to that exact path. You should see `run_pipeline.py` listed there. If not, the path is wrong and the notebook will fail with `ModuleNotFoundError: run_pipeline` when Run executes.

---

## 6. Step 5 — Edit `app.yaml` to match YOUR paths

In Databricks workspace browser:

1. Navigate to `/Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend/app.yaml`
2. Click on the file → **Edit**
3. Find these env vars and update them. **All paths must match folders that actually exist** in your workspace.

```yaml
- name: DBX_GENERATED_DIR
  value: "/Workspace/Users/YOUR.EMAIL/YOUR/PATH/dbx_ingestion/domain-configs/sources/generated"

- name: DBX_ENV_DIR
  value: "/Workspace/Users/YOUR.EMAIL/YOUR/PATH/dbx_ingestion/domain-configs/env-overrides"

- name: DBX_NOTEBOOK_PATH
  value: "/Workspace/Users/YOUR.EMAIL/YOUR/PATH/dbx_ingestion/Data-Platform/NoteBook_Main_Param"

- name: DBX_DEFAULT_CLUSTER_ID
  value: "0501-YOUR-CLUSTER-ID"
```

Replace the values to match your actual workspace structure. Notes:

- **`DBX_GENERATED_DIR`** — used by the Save button. The folder doesn't need to exist for Run anymore (we removed that dependency), but it does for Save. If you don't plan to use Save, you can leave the default — Save will fail but Run still works.
- **`DBX_ENV_DIR`** — points at the folder containing your `dev.yaml` and `prod.yaml` env-overrides. Used at runtime by `run_pipeline.run()`.
- **`DBX_NOTEBOOK_PATH`** — must exactly match where you created `NoteBook_Main_Param` in Step 3. **No `.py` extension** — Databricks notebook paths don't include it.
- **`DBX_DEFAULT_CLUSTER_ID`** — must be a valid cluster ID. We hardcode it directly because resource bindings (`valueFrom: default_cluster`) sometimes don't work correctly through the UI deploy path.

If your workspace also has a SQL warehouse, also set:

```yaml
- name: DBX_WAREHOUSE_ID
  value: "1a2b3c4d-YOUR-WAREHOUSE-ID"
```

If you don't have a warehouse, comment out that line — the History tab won't work but everything else will.

Save the file.

---

## 7. Step 6 — Create the App and bind the cluster

In Databricks:

1. **Compute** in the left sidebar → **Apps** tab → **Create app**
2. Choose **Custom** (not a template)
3. **App name**: `dbx-ingestion-ui` *(lowercase, hyphens, no spaces — becomes part of URL)*
4. **Description**: "Self-service Bronze ingestion config & runner"
5. Click **Next**

On the resources page:

6. **Add resource** → **Compute (cluster)**
   - Resource name: `default_cluster`
   - Cluster: pick yours
   - Permission: Can attach to + Can restart

7. *(Optional, only if you have a SQL warehouse)* **Add resource** → **SQL warehouse**
   - Resource name: `history_warehouse`
   - SQL warehouse: pick yours
   - Permission: Can use

> **Important**: even though we hardcoded the cluster ID in `app.yaml`, you still need to bind the cluster as a resource so the App has permission to use it. The hardcoded ID just bypasses the `valueFrom` lookup quirk we hit earlier.

Click **Next**.

On the source code page:

8. **Source code path**: click the folder picker
9. Navigate to `/Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend`
10. Click **Select**

The path you pick must contain `app.py` and `app.yaml` directly — that's `backend/`, not the parent folder.

The **Command** field should auto-fill with `uvicorn app:app --host 0.0.0.0 --port 8000` (read from `app.yaml`). If it doesn't auto-fill, the path is wrong.

Click **Create**.

---

## 8. Step 7 — Smoke test

Wait for status to show **RUNNING** (~2-3 minutes on first deploy).

Click the App URL at the top of the page. You should see the Build tab with the source connection form.

**Test the full flow:**

1. **Source name**: type `smoke_test`
2. **Database type**: pick Redshift (or whatever yours is)
3. **Host / Port / Database**: fill in real values
4. **Secret scope / user / password keys**: fill in real values
5. Click **📋 Bulk add** in the Tables card header
6. In the modal, paste:
   ```
   public.fact_orders
   public.dim_customer
   ```
7. Click **Add 2 tables**
8. **Preview YAML** tab — confirm the YAML is generated
9. **Run pipeline** button
10. Switch to **Run Status** tab — should see PENDING → RUNNING within 30s
11. Wait for SUCCESS or FAILED

**Two outcomes**

- **SUCCESS**: you're done. Deployment complete.
- **FAILED**: the Run Status tab will now show a **red banner with the error message** at the top (this is one of the new fixes). Tells you exactly what went wrong on the cluster side. Fix the underlying issue (notebook path, env-overrides path, secret access, etc.) and try again.

---

## 9. If something breaks

The App's **Logs** tab on the App page is your friend. Click it, scroll to the bottom, look for red `ERROR` lines and Python tracebacks. The bottom 5-10 lines almost always tell you exactly what's wrong.

Common errors and fixes:

| Error message contains | Fix |
|---|---|
| `RuntimeError: DBX_DEFAULT_CLUSTER_ID is not set` | Edit `app.yaml`, hardcode the cluster ID directly with `value:` (not `valueFrom:`). Stop+Start the App. |
| `ResourceDoesNotExist: parent folder ... does not exist` | The path in `app.yaml` doesn't exist in workspace. Either fix the path or create the folder. |
| `Notebook ... does not exist` *(in run logs)* | `DBX_NOTEBOOK_PATH` is wrong, OR `NoteBook_Main_Param` was created as a File instead of a Notebook. |
| `ModuleNotFoundError: run_pipeline` *(in run logs)* | The `sys.path.insert(...)` line in `NoteBook_Main_Param` points at a non-existent path. Re-edit the notebook to match your actual `platform-core` location. |
| `INTERNAL_ERROR` state | Click into the run in Workflows → Job runs → see the actual error. The App now shows `state_message` in a red banner too. |
| App is RUNNING but page is blank | `backend/static/index.html` didn't get uploaded. Re-run Step 2. |
| `{"detail": "Not Found"}` at root URL | Same — frontend missing. Confirm `backend/static/index.html` exists in workspace. |
| App stuck STARTING for >5 min | Check Logs tab for Python errors. Most often a missing dependency or a misconfigured env var. |

---

## 10. Updating later

When you change anything (`app.yaml`, source code, etc.) you have two paths.

**For backend code changes** (any `.py` file in `backend/`):

```bash
# On your laptop
cd dbx_ingestion_app
databricks workspace import-dir backend \
  /Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend \
  --overwrite

# Then in Databricks UI:
# App page → click Deploy → wait ~15 sec
```

**For `app.yaml` changes only** (env vars, command):

Edit the file directly in the workspace browser → Save → App page → Stop → Start. The Stop+Start is more reliable than just Deploy when env vars change.

**For frontend changes** (only matters if you decide to rebuild from `frontend/` source later):

Skip this for now. The pre-built `static/index.html` we shipped is what you're running. Only relevant if you have Node.js available somewhere and want the full React build with the modal browser.

---

## Reference: what goes where

```
On your laptop (after unzip):
dbx_ingestion_app/
├── backend/                    ← upload to workspace
│   ├── app.py
│   ├── app.yaml                ← edit before/after upload
│   ├── ...
│   └── static/index.html       ← pre-built UI (already inside)
├── databricks/
│   └── NoteBook_Main_Param.py  ← copy contents to workspace notebook
├── frontend/                   ← not deployed (source for rebuilding)
└── docs/                       ← reference only

In Databricks workspace:
/Workspace/Users/YOUR.EMAIL/
├── dbx_ingestion_app/          ← this is where backend/ uploads to
│   └── backend/                ← App's "Source code path" points here
│       ├── app.py
│       ├── app.yaml
│       └── static/index.html
└── YOUR/PATH/dbx_ingestion/    ← your existing pipeline (unchanged)
    ├── Data-Platform/
    │   ├── NoteBook_Main.py    ← already here, untouched
    │   ├── NoteBook_Main_Param ← NEW — paste from databricks/NoteBook_Main_Param.py
    │   └── platform-core/
    │       └── run_pipeline.py
    └── domain-configs/
        ├── env-overrides/
        │   └── dev.yaml
        └── sources/
            └── (existing yamls — unchanged)
```

---

## Reference: env vars in app.yaml

| Variable | Purpose | Required for |
|---|---|---|
| `DBX_GENERATED_DIR` | Where Save writes generated YAMLs | Save button |
| `DBX_ENV_DIR` | Where `dev.yaml` / `prod.yaml` env overrides live | Run pipeline (cluster reads from here) |
| `DBX_NOTEBOOK_PATH` | Notebook the Run button executes | Run pipeline |
| `DBX_DEFAULT_CLUSTER_ID` | Cluster the run executes on | Run pipeline |
| `DBX_WAREHOUSE_ID` | SQL warehouse for History + future schema browser | History tab |
| `DBX_CATALOG` | Catalog containing `platform_meta.pipeline_runs` | History tab |
| `DBX_META_SCHEMA` | Schema containing audit tables (default: `platform_meta`) | History tab |
| `LOG_LEVEL` | Backend log verbosity (default: INFO) | optional |

---

## Fallback: uploading without the CLI

If you absolutely can't install the CLI on your laptop, use this notebook trick:

1. In Databricks, create a new notebook anywhere
2. **Drag-drop the entire `dbx_ingestion_app.zip` file onto the notebook** — Databricks uploads it as an attachment to your user folder
3. In a Python cell, paste:

```python
import zipfile
import shutil
import os

# Adjust this — wherever Databricks placed your uploaded zip
zip_path = "/Workspace/Users/YOUR.EMAIL/dbx_ingestion_app.zip"

# Where to extract
target_root = "/Workspace/Users/YOUR.EMAIL"

# Extract just the backend/ folder
with zipfile.ZipFile(zip_path) as z:
    for member in z.namelist():
        if member.startswith("dbx_ingestion_app/backend/"):
            z.extract(member, "/tmp")

# Copy backend into workspace
src = "/tmp/dbx_ingestion_app/backend"
dst = f"{target_root}/dbx_ingestion_app/backend"

if os.path.exists(dst):
    shutil.rmtree(dst)
shutil.copytree(src, dst)

print(f"Uploaded to {dst}")
print("Files:", os.listdir(dst))
```

4. Run the cell. After it succeeds, continue with Step 3 onward.

This works without any laptop tooling beyond your browser. The cluster does the heavy lifting.
