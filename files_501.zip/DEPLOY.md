# DEPLOY.md — File-free deployment guide

This release skips Workspace YAML files entirely. The App passes config + env-overrides as inline JSON to the parameterized notebook, which calls a new `run_from_dict()` entry point on your existing `run_pipeline.py`. No YAMLs are written or read during a Run.

---

## What changed vs. the older flow

| | Older flow | This release |
|---|---|---|
| Save → write YAML to `generated/` | Required | Skipped |
| Read env-overrides YAML | Required | Skipped |
| Folders that must exist in workspace | 3 (generated/, env-overrides/, NoteBook_Main_Param) | 1 (NoteBook_Main_Param) |
| Permissions to grant | Folder + notebook + cluster | Notebook + cluster |

The Save button still writes to `generated/` for users who want a persistent copy (audit trail). But Run no longer depends on it.

---

## Prerequisites

- Databricks workspace with Apps enabled
- An all-purpose cluster (RUNNING when you click Run)
- Your existing pipeline code already in the workspace (Data-Platform/ + platform-core/)
- Permission to create Apps and edit workspace files
- Databricks CLI on your laptop *(or use the notebook fallback at the end)*

Install the CLI if you don't have it:
```bash
# macOS / Linux
curl -fsSL https://raw.githubusercontent.com/databricks/setup-cli/main/install.sh | sh

# Windows (PowerShell)
winget install Databricks.DatabricksCLI

# Auth
databricks auth login --host https://YOUR-WORKSPACE.cloud.databricks.com
```

---

## Step 1 — Patch your `run_pipeline.py`

This release adds `run_from_dict()` to your existing `run_pipeline.py`. Your existing `run(config_path, env_path)` is unchanged.

The package includes `databricks/run_pipeline.py` — a complete drop-in replacement that adds `run_from_dict()` while preserving the original `run()`, `inject_env_values()`, `_dispatch_run()`, `_print_verification_sql()`, and CLI behavior.

1. Open `databricks/run_pipeline.py` from this package
2. Copy the entire contents
3. In Databricks, navigate to `/Workspace/Users/YOUR.EMAIL/.../dbx_ingestion/Data-Platform/platform-core/run_pipeline.py`
4. Open in editor, select all, paste the new contents
5. Save

---

## Step 2 — Find your IDs and paths

Collect into a notes file:

| What | Example |
|---|---|
| Your user folder | `ashoka.pallapu@amtrak.com` |
| Path to `platform-core/` | `/Workspace/Users/.../dbx_ingestion/Data-Platform/platform-core` |
| Path to your `Data-Platform/` folder *(parent of `NoteBook_Main`)* | `/Workspace/Users/.../dbx_ingestion/Data-Platform` |
| Cluster ID | `0501-XXXXXX-abcdef` *(from Compute → cluster URL)* |
| SQL Warehouse ID *(optional, for History)* | `1a2b3c4d5e6f7g8h` *(from SQL Warehouses → URL)* |

---

## Step 3 — Upload the App backend

Unzip the package on your laptop:

```bash
unzip dbx_ingestion_app.zip
cd dbx_ingestion_app
```

Upload the `backend/` folder:

```bash
databricks workspace import-dir backend \
  /Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend
```

Verify:

```bash
databricks workspace list /Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend
```

You should see `app.py`, `app.yaml`, `static/`, etc.

---

## Step 4 — Upload `NoteBook_Main_Param`

This file goes **next to your existing `NoteBook_Main`**, not inside the App folder. The notebook needs to be there to import platform-core code.

In Databricks workspace browser:

1. Navigate to your `Data-Platform/` folder
2. **Create** → **Notebook** *(NOT File)*
3. Name: `NoteBook_Main_Param` *(no `.py` extension)*
4. Default language: Python
5. Click **Create**
6. The empty notebook opens

Now copy the contents:

7. On your laptop, open `databricks/NoteBook_Main_Param.py` in any text editor
8. Copy entire contents
9. Paste into the Databricks notebook editor

Before saving, edit one line near the top:

```python
PLATFORM_CORE_PATH = (
    "/Workspace/Users/your.email@company.com"
    "/dbx_ingestion/Data-Platform/platform-core"
)
```

Replace with **your actual path to platform-core/** from Step 2. Then save (Cmd-S / Ctrl-S).

> **Verify it's right**: navigate to that exact path in your workspace. You should see `run_pipeline.py` listed there.

---

## Step 5 — Edit `app.yaml`

Open `/Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend/app.yaml` in the workspace editor.

Update these values to match YOUR workspace:

```yaml
- name: DBX_NOTEBOOK_PATH
  value: "/Workspace/Users/YOUR.EMAIL/.../dbx_ingestion/Data-Platform/NoteBook_Main_Param"

- name: DBX_DEFAULT_CLUSTER_ID
  value: "0501-XXXXXX-YOUR_CLUSTER_ID"

- name: DBX_CATALOG
  value: "ops_dev"

- name: DBX_SECRETS_SUFFIX
  value: "-dev"

- name: DBX_SECRETS_SCOPE
  value: "data-platform-dev"
```

If you have a SQL warehouse:

```yaml
- name: DBX_WAREHOUSE_ID
  value: "YOUR_WAREHOUSE_ID"
```

If not, comment out that line — the History tab won't work but everything else does.

Save the file.

---

## Step 6 — Create the App

In Databricks:

1. **Compute** → **Apps** tab → **Create app** → **Custom**
2. **App name**: `dbx-ingestion-ui` *(lowercase, no spaces)*
3. **Description**: anything you want
4. Click **Next**

On the resources page:

5. **Add resource** → **Compute (cluster)**
   - Resource name: `default_cluster`
   - Cluster: pick yours
   - Permission: Can attach to + Can restart

6. *(Optional)* **Add resource** → **SQL warehouse**
   - Resource name: `history_warehouse`
   - Permission: Can use

> **Important**: even though we hardcoded the cluster ID in `app.yaml`, you still need to bind the cluster as a resource so the App has permission to use it.

7. Click **Next**

On the source code page:

8. **Source code path**: click the folder picker, navigate to `/Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend`, click **Select**

The path you pick must contain `app.py` and `app.yaml` directly.

9. The **Command** field should auto-fill with `uvicorn app:app --host 0.0.0.0 --port 8000`

10. Click **Create**

---

## Step 7 — Grant the App service principal permissions

The App runs as its own service principal (something like `app-XXXXXX-...`), not as you. It needs explicit permission to read your platform code and run on your cluster.

**Find the service principal name**: App page → look for "Service principal" or "Identity" — copy that exact name.

**Grant 3 permissions:**

1. **Notebook**: Right-click `NoteBook_Main_Param` → Permissions → add SP with **Can Run**
2. **Parent folder**: Right-click your `dbx_ingestion/` folder (top-level) → Permissions → add SP with **Can Read** *(propagates to platform-core)*
3. **Cluster**: Compute → your cluster → Permissions → add SP with **Can Restart**

---

## Step 8 — Smoke test

Wait for App status to show **RUNNING** (~2-3 minutes).

Click the App URL.

1. **Source name**: `smoke_test`
2. **Database type**: pick yours
3. **Host / Port / Database**: real values
4. **Secret scope / user / password keys**: real values
5. Click **📋 Bulk add** and paste a few table names
6. Click **Add N tables**
7. **Preview YAML** tab — confirm the YAML looks right
8. **Run pipeline**
9. **Run Status** tab — watch progress

If RUNNING → SUCCESS, you're done. If FAILED, the Run Status tab shows a red banner with the actual error message from Databricks.

---

## If something breaks

The App's **Logs** tab shows backend errors. The Databricks **Workflows → Job runs** tab shows pipeline errors.

Common errors and fixes:

| Error contains | Fix |
|---|---|
| `DBX_DEFAULT_CLUSTER_ID is not set` | Hardcode the cluster ID in `app.yaml` with `value:` (not `valueFrom:`). Stop+Start the App. |
| `Notebook does not exist` | `DBX_NOTEBOOK_PATH` is wrong, OR `NoteBook_Main_Param` was created as a File instead of a Notebook. |
| `lacks the required permissions` | App service principal needs Can Run on the notebook + Can Read on the parent folder + Can Restart on the cluster. |
| `ModuleNotFoundError: run_pipeline` | The `PLATFORM_CORE_PATH` constant in `NoteBook_Main_Param` doesn't match where `run_pipeline.py` actually lives. |
| `cannot import name 'run_from_dict'` | Your `run_pipeline.py` wasn't patched in Step 1 — the new function isn't there. |
| `INTERNAL_ERROR` state | App service principal is missing one of the 3 permissions above. |
| App is RUNNING but page is blank | `backend/static/index.html` didn't get uploaded. Re-run Step 3. |

---

## How the file-free flow works

```
   ┌──────────────────────┐
   │  User clicks Run     │
   │  in the UI           │
   └──────────┬───────────┘
              │
              ▼
   ┌──────────────────────────────────────────────────┐
   │  POST /api/run                                    │
   │    config_dict = build_dict(form)                 │
   │    env_dict    = {catalog, scope, ...}            │
   │    trigger_run(config=, env=, ...)                │
   └──────────┬────────────────────────────────────────┘
              │  json.dumps + Jobs API submit
              ▼
   ┌──────────────────────────────────────────────────┐
   │  NoteBook_Main_Param  (on cluster)                │
   │    config = json.loads(config_json)               │
   │    env    = json.loads(env_json)                  │
   │    run_from_dict(config, env)                     │
   └──────────┬────────────────────────────────────────┘
              │
              ▼
   ┌──────────────────────────────────────────────────┐
   │  run_pipeline.run_from_dict()                     │
   │    serialize → inject env → dispatch              │
   │    same templates as before                       │
   └──────────────────────────────────────────────────┘
```

No Workspace folders are touched between the App and the cluster. The only writes happen at the very end (the temp YAML inside `_dict_to_injected_yaml`), which lives on the cluster's local filesystem and is deleted automatically.

---

## Reference: env vars in app.yaml

| Variable | Purpose | Required for |
|---|---|---|
| `DBX_NOTEBOOK_PATH` | Notebook the Run button executes | Run pipeline |
| `DBX_DEFAULT_CLUSTER_ID` | Cluster the run executes on | Run pipeline |
| `DBX_CATALOG` | Substitutes `__CATALOG__` placeholder | Run pipeline |
| `DBX_SECRETS_SCOPE` | Substitutes `__SECRETS_SCOPE__` placeholder | Run pipeline |
| `DBX_SECRETS_SUFFIX` | Substitutes `__SECRETS_SUFFIX__` placeholder | Run pipeline |
| `DBX_STORAGE_ROOT` | Substitutes `__STORAGE_ROOT__` (S3 sources only) | S3 ingestion |
| `DBX_WAREHOUSE_ID` | SQL warehouse for History tab | History tab |
| `DBX_META_SCHEMA` | Schema with audit tables (default: `platform_meta`) | History tab |
| `LOG_LEVEL` | Backend log verbosity | optional |

Variables **removed** from this release (no longer used):

| Removed | Why |
|---|---|
| `DBX_GENERATED_DIR` | Save still uses it but Run no longer does |
| `DBX_ENV_DIR` | env-overrides YAMLs are no longer read |

If your old `app.yaml` had these, they're harmless but unused.

---

## Updating later

```bash
cd dbx_ingestion_app
databricks workspace import-dir backend \
  /Workspace/Users/YOUR.EMAIL/dbx_ingestion_app/backend \
  --overwrite

# In Databricks UI: App page → Stop → Start
```

---

## Fallback: uploading without the CLI

If you can't install the CLI on your laptop:

1. Drag-drop `dbx_ingestion_app.zip` onto a Databricks notebook *(uploads as attachment)*
2. Run this cell:

```python
import zipfile, shutil, os

zip_path    = "/Workspace/Users/YOUR.EMAIL/dbx_ingestion_app.zip"
target_root = "/Workspace/Users/YOUR.EMAIL"

with zipfile.ZipFile(zip_path) as z:
    for member in z.namelist():
        if member.startswith("dbx_ingestion_app/backend/"):
            z.extract(member, "/tmp")

src = "/tmp/dbx_ingestion_app/backend"
dst = f"{target_root}/dbx_ingestion_app/backend"

if os.path.exists(dst):
    shutil.rmtree(dst)
shutil.copytree(src, dst)
print("Uploaded:", os.listdir(dst))
```

3. Continue from Step 4.
