# Databricks notebook source
# ============================================================================
# NoteBook_Main_Param.py
# ----------------------------------------------------------------------------
# Parameterized version of NoteBook_Main.py. The Databricks Ingestion UI
# triggers this notebook via Jobs runs/submit and passes:
#
#     config_yaml  → the full YAML config content (string), inlined
#     source_name  → used to build a unique temp filename for the cluster
#     env_path     → /Workspace/.../env-overrides/<env>.yaml
#
# We write the inline YAML to a local temp file on the cluster and hand that
# path to run_pipeline.run() — which is unchanged. This avoids needing a
# Workspace-level "generated/" folder to exist for the Run flow.
#
# This is the only NEW file we add to the existing repo — everything else
# (run_pipeline.py, bronze_rdbms_multi_template.py, etc.) is untouched.
# ============================================================================
import os
import sys
import tempfile
from datetime import datetime

# Same path-bootstrap as the existing notebook so we can import platform-core
# Update this path if your platform code lives elsewhere in your workspace.
sys.path.insert(
    0,
    "/Workspace/Users/your.email@company.com/dbx_ingestion/Data-Platform/platform-core",
)

from run_pipeline import run

# COMMAND ----------

# ── Pull params injected by the UI / Jobs API ────────────────────────────────
# dbutils is provided by the Databricks runtime — the linter doesn't see it.
dbutils.widgets.text("config_yaml", "", "Inline YAML config content")    # noqa: F821
dbutils.widgets.text("source_name", "",  "Source name (for temp filename)") # noqa: F821
dbutils.widgets.text("env_path",    "",  "Path to env-overrides YAML")    # noqa: F821

# Backward compatibility: also accept the old config_path widget.
dbutils.widgets.text("config_path", "",  "(legacy) workspace path to YAML") # noqa: F821

config_yaml  = dbutils.widgets.get("config_yaml")    # noqa: F821
source_name  = dbutils.widgets.get("source_name")    # noqa: F821
env_path     = dbutils.widgets.get("env_path")       # noqa: F821
legacy_path  = dbutils.widgets.get("config_path")    # noqa: F821

if not env_path:
    raise ValueError("env_path widget is required (set by the UI / Jobs API).")

# COMMAND ----------

# ── Resolve the config path ─────────────────────────────────────────────────
# Three modes (in priority order):
#   1. config_yaml is set → write it to a temp file on the cluster, use that
#   2. config_path is set (legacy) → use it directly as a workspace path
#   3. Neither is set → fail with a clear error

if config_yaml:
    # Write the inlined YAML to a unique temp file on the cluster's local FS.
    # /tmp is always writable on Databricks clusters.
    safe_name = (source_name or "config").replace("/", "_").replace(" ", "_")
    timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    config_path = os.path.join(tempfile.gettempdir(), f"{safe_name}_{timestamp}.yaml")

    with open(config_path, "w", encoding="utf-8") as f:
        f.write(config_yaml)

    print(f"[NoteBook_Main_Param] wrote {len(config_yaml)} bytes → {config_path}")

elif legacy_path:
    config_path = legacy_path
    print(f"[NoteBook_Main_Param] using legacy config_path = {config_path}")

else:
    raise ValueError(
        "Either 'config_yaml' (inline YAML) or 'config_path' (workspace file) "
        "must be provided as a widget parameter."
    )

print(f"config_path = {config_path}")
print(f"env_path    = {env_path}")

# COMMAND ----------

# ── Hand off to the existing dispatcher — zero changes downstream ───────────
run(config_path=config_path, env_path=env_path)
